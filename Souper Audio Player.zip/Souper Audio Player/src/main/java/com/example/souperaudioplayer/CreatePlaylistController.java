package com.example.souperaudioplayer;

import java.io.IOException;

public class CreatePlaylistController {

    public void quit() throws IOException {
        MainApplication.change(0);
    }
}
